Renders a DOM node or an array of DOM nodes to a string.
